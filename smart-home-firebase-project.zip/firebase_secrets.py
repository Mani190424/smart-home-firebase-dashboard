# 🔐 Firebase Configuration
FIREBASE_URL = "https://smart-home-live-data-default-rtdb.firebaseio.com/"
